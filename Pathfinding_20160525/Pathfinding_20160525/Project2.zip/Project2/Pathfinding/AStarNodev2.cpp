#include "DXUT.h"
#include "AStarNodev2.h"
#undef max

AStarNodev2::AStarNodev2() : xCoord(-1), yCoord(-1), closed(false), open(false), parent(NULL), totalCost(std::numeric_limits<float>::max()), cost(totalCost) {}
AStarNodev2::AStarNodev2(int x, int y) : xCoord(x), yCoord(y), closed(false), open(false), parent(NULL), cost(std::numeric_limits<float>::max()), totalCost(cost) {}
AStarNodev2::AStarNodev2(int x, int y, bool o, bool c) : xCoord(x), yCoord(y), open(o), closed(c), cost(std::numeric_limits<float>::max()), totalCost(cost), parent(NULL) {}
AStarNodev2::AStarNodev2(int x, int y, bool o, bool c, float co, float tc) : parent(NULL), xCoord(x), yCoord(y), open(o), closed(c), cost(co), totalCost(tc) {}
AStarNodev2::AStarNodev2(const AStarNodev2& r) : xCoord(r.getX()), yCoord(r.getY()), open(r.getOpen()), closed(r.getClosed()), cost(r.getCost()), totalCost(r.getTotalCost()), parent(r.getParent()){}

int AStarNodev2::getX() const
{
	return xCoord;
}

int AStarNodev2::getY() const
{
	return yCoord;
}

bool AStarNodev2::getOpen() const
{
	return open;
}

bool AStarNodev2::getClosed() const
{
	return closed;
}

float AStarNodev2::getCost() const
{
	return cost;
}

float AStarNodev2::getTotalCost() const
{
	return totalCost;
}

AStarNodev2* AStarNodev2::getParent() const
{
	return parent;
}

void AStarNodev2::setX(int x)
{
	xCoord = x;
}

void AStarNodev2::setY(int x)
{
	yCoord = x;
}

void AStarNodev2::setOpen(bool x)
{
	open = x;
}

void AStarNodev2::setClosed(bool x)
{
	closed = x;
}

void AStarNodev2::setParent(AStarNodev2* p)
{
	parent = p;
}

void AStarNodev2::setCost(float f)
{
	cost = f;
}

void AStarNodev2::setTotalCost(float f)
{
	totalCost = f;

}

void AStarNodev2::clearNode()
{
	this->setParent(NULL);
	this->setOpen(false);
	this->setClosed(false);
	this->setCost(std::numeric_limits<float>::max());
	this->setTotalCost(cost);


}

void AStarNodev2::deleteNode()
{
	this->setX(-1);
		this->setY(-1);
		this->setParent(NULL);
		this->setOpen(false);
		this->setClosed(false);
		this->setCost(std::numeric_limits<float>::max());
		this->setTotalCost(cost);

}

const AStarNodev2& AStarNodev2::operator=(const AStarNodev2& rhs)
{
	this->setX(rhs.getX());
	this->setY(rhs.getY());
	this->setParent(rhs.getParent());
	this->setOpen(rhs.getOpen());
	this->setClosed(rhs.getClosed());
	this->setCost(rhs.getCost());
	this->setTotalCost(rhs.getTotalCost());
	return *this;
}


AStarNodev2::~AStarNodev2() {}
