#include "DXUT.h"
#include "AStarNodev2.h"
#undef max


AStarNodev2::AStarNodev2() : xCoord(-1), yCoord(-1), closed(false), open(false), parent(NULL), cost(std::numeric_limits<float>::max()), totalCost(cost)
{
}

AStarNodev2::AStarNodev2(int x, int y) : xCoord(x), yCoord(y), closed(false), open(false), parent(NULL), cost(std::numeric_limits<float>::max()), totalCost(cost) {}

AStarNodev2::AStarNodev2(int x, int y, bool b, bool c) : xCoord(x), yCoord(y), closed(b), open(c), parent(NULL), cost(std::numeric_limits<float>::max()), totalCost(cost) {}
AStarNodev2::AStarNodev2(int x, int y, bool c, bool o, float co, float tc) : xCoord(x), yCoord(y), open(o), closed(c), parent(NULL), cost(co), totalCost(tc) {}
AStarNodev2::AStarNodev2(const AStarNodev2& n) : xCoord(n.getX()), yCoord(n.getY()), open(n.getOpen()), closed(n.getClosed()), parent(n.getParent()), cost(n.getCost()), totalCost(n.getTotalCost()) {}

int AStarNodev2::getX() const { return xCoord; }
int AStarNodev2::getY() const { return yCoord; }
bool AStarNodev2::getOpen() const { return open; }
bool AStarNodev2::getClosed() const { return closed; }
float AStarNodev2::getCost() const { return cost; }
float AStarNodev2::getTotalCost() const { return totalCost; }
AStarNodev2* AStarNodev2::getParent() const { return parent; }

void AStarNodev2::setX(int x) { xCoord = x; }
void AStarNodev2::setY(int x) { yCoord = x; }
void AStarNodev2::setOpen(bool b) { open = b; }
void AStarNodev2::setClosed(bool b) { closed = b; }
void AStarNodev2::setParent(AStarNodev2* p) { parent = p; }
void AStarNodev2::setCost(float c) { cost = c; }
void AStarNodev2::setTotalCost(float c) { totalCost = c; }
void AStarNodev2::clearNode(){ this->setOpen(false);  this->setClosed(false);  this->setParent(NULL);  this->setCost(std::numeric_limits<float>::max());  this->setTotalCost(std::numeric_limits<float>::max()); }
void AStarNodev2::deleteNode() { this->setX(-1);  this->setY(-1); this->setOpen(false);  this->setClosed(false);  this->setParent(NULL);  this->setCost(std::numeric_limits<float>::max());  this->setTotalCost(std::numeric_limits<float>::max()); }

const AStarNodev2& AStarNodev2::operator=(const AStarNodev2& n)
{
	this->setX(n.getX());
	this->setY(n.getY());
	this->setOpen(n.getOpen());
	this->setClosed(n.getClosed());
	this->setParent(n.getParent());
	this->setCost(n.getCost());
	this->setTotalCost(n.getTotalCost());

	return *this;
}


AStarNodev2::~AStarNodev2()
{
}
